configure({
  sources: [
    source('amd', 'tinymce.modern', '../../src/main/js', mapper.hierarchical)
  ]
});
