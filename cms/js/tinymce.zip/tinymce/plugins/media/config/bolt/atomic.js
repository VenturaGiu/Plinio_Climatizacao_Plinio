configure({
  configs: [
    './prod.js'
  ]
});